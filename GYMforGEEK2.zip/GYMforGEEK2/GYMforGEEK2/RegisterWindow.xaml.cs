﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace GYMforGEEK2
{
    /// <summary>
    /// Логика взаимодействия для RegisterWindow.xaml
    /// </summary>
    public partial class RegisterWindow : Window
    {
        public RegisterWindow()
        {
            InitializeComponent();
        }
        readonly WpfApp1.Classes.DataBase dataBase = new WpfApp1.Classes.DataBase();

        private void Register_Click(object sender, RoutedEventArgs e)
        {
            string surname = txtSurname.Text;
            string name = txtName.Text;
            string fathername = txtFathername.Text;
            string login = txtLogin.Text;
            string password = txtPassword.Password;
            string confirmPassword = txtConfirmPassword.Password;
            int roles=2;

            if (surname!=null && name!=null && fathername!=null && login!=null)
            {
                if (password != confirmPassword)
                {
                    MessageBox.Show("Пароли не совпадают");
                    return;
                }
                else
                {
                    dataBase.AddUser(surname, name, fathername, login, password, roles);
                    MessageBox.Show("Регистрация прошла успешно");
                    LoginWindow shop = new LoginWindow();
                    shop.Show();
                    this.Close();

                }
            }
            else
            {
                MessageBox.Show("Вы не ввели необходимые данные");

            }

        }
    }
}
