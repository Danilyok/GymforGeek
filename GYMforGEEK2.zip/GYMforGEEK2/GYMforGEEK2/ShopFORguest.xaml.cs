﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace GYMforGEEK2
{
    /// <summary>
    /// Логика взаимодействия для ShopFORguest.xaml
    /// </summary>
    public partial class ShopFORguest : Window
    {
        readonly WpfApp1.Classes.DataBase data = new WpfApp1.Classes.DataBase();
        public ShopFORguest()
        {
            InitializeComponent();
            ProductsListView();
        }

        private void ProductsListView()
        {
            DataTable dt = data.SqlSelect("Select * from Товары");
            LWProduct.ItemsSource = dt.DefaultView;
            data.CloseConnection();
        }
        private void ButtonBack_Click(object sender, RoutedEventArgs e)
        {
            MainWindow main = new MainWindow();

            // Переход на новое окно
            main.Show();

            // Закрытие текущего окна
            this.Close();
        }
    }
}
