﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace GYMforGEEK2
{
    /// <summary>
    /// Логика взаимодействия для ShopFORuser.xaml
    /// </summary>
    public partial class ShopFORuser : Window
    {
        readonly WpfApp1.Classes.DataBase data = new WpfApp1.Classes.DataBase();
        public ShopFORuser()
        {
            InitializeComponent();
            ProductsListView();
        }
        private void ProductsListView()
        {
            DataTable dt = data.SqlSelect("Select * from Товары");
            LWProduct.ItemsSource = dt.DefaultView;
            data.CloseConnection();
        }
        private void ButtonCart_Click(object sender, RoutedEventArgs e)
        {
            Cart cart = new Cart();

            // Переход на новое окно
            cart.Show();

            
        }
        private void ButtonBack_Click(object sender, RoutedEventArgs e)
        {
            MainWindow main = new MainWindow();
            main.Show();
            this.Close();
        
        }
    }
}
