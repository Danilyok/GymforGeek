﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp1.Classes
{
    public class DataBase
    {
        public static string connectionString = @"Data Source=LAPTOP-VF6RUNDD; DataBase=GYMforGEEK; Integrated Security=True; Trusted_Connection=true; MultipleActiveResultSets=true; TrustServerCertificate=true; encrypt=false;";
        private readonly SqlConnection connection = new SqlConnection(connectionString);

        public DataTable SqlSelect(string cmd)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                SqlCommand command = new SqlCommand(cmd, conn);
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    DataTable dt = new DataTable();
                    dt.Load(reader);
                    reader.Close();
                    return dt;
                }
            }
        }

        public DataTable SqlInsert(string cmd)
        {
            SqlConnection conn = new SqlConnection(connectionString);
            conn.Open();
            SqlCommand command = new SqlCommand(cmd, conn);
            command.ExecuteNonQuery();
            SqlDataAdapter adapter = new SqlDataAdapter(command);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            return dt;
        }

        public void AddUser(string surname, string name, string fathername, string login, string password, int roles)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string query = "INSERT INTO Пользователи (Фамилия, Имя, Отчество, Логин, Пароль, FK_роли) VALUES (@Surname, @Name, @Fathername, @Login, @Password, @Roles)";

                using (SqlCommand cmd = new SqlCommand(query, connection))
                {
                    cmd.Parameters.AddWithValue("@Surname", surname);
                    cmd.Parameters.AddWithValue("@Name", name);
                    cmd.Parameters.AddWithValue("@Fathername", fathername);
                    cmd.Parameters.AddWithValue("@Login", login);
                    cmd.Parameters.AddWithValue("@Password", password);
                    cmd.Parameters.AddWithValue("@Roles", roles=2);

                    cmd.ExecuteNonQuery();
                }
            }
        }
        public void AddProduct(string name, string descr, int category, string path, int costP)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string query = "INSERT INTO Товары (Название_товара, Производитель_товара, FK_Категория_товара, Фото_товара, Цена_товара) VALUES (@Name, @Descr, @Category, @Path, @CostP)";

                using (SqlCommand cmd = new SqlCommand(query, connection))
                {
                    cmd.Parameters.AddWithValue("@Name", name);
                    cmd.Parameters.AddWithValue("@Descr", descr);
                    cmd.Parameters.AddWithValue("@Category", category);
                    cmd.Parameters.AddWithValue("@Path", path);
                    cmd.Parameters.AddWithValue("@CostP", costP);

                    cmd.ExecuteNonQuery();
                }
            }
        }

        public void AddPokupki(string name, string tovarr, string kolichestvo, int costP)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string query = "INSERT INTO Покупки (FK_пользователя, FK_товара, Количество, Сумма) VALUES (@Name, @Descr, @Category, @CostP)";

                using (SqlCommand cmd = new SqlCommand(query, connection))
                {
                    cmd.Parameters.AddWithValue("@Name", name);
                    cmd.Parameters.AddWithValue("@Descr", tovarr);
                    cmd.Parameters.AddWithValue("@Category", kolichestvo);
                    cmd.Parameters.AddWithValue("@CostP", costP);

                    cmd.ExecuteNonQuery();
                }
            }
        }


        /// <summary>
        /// Метод для открытия соединения с БД
        /// </summary>
        public void OpenConnection()
        {
            // Если состояние строки закрыто, открываем
            if (connection.State == System.Data.ConnectionState.Closed)
            {
                connection.Open();
            }
        }

        /// <summary>
        /// Метод для закрытия соединения с БД
        /// </summary>
        public void CloseConnection()
        {
            // Если состояние строки открыто, закрываем
            if (connection.State == System.Data.ConnectionState.Open)
            {
                connection.Close();
            }
        }

        /// <summary>
        /// Метод для возвращения строки подключения
        /// </summary>
        /// <returns></returns>
        public SqlConnection GetConnection()
        {
            return connection;
        }
    }
}