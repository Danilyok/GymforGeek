﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace GYMforGEEK2
{
    /// <summary>
    /// Логика взаимодействия для ShopPage.xaml
    /// </summary>
    public partial class ShopPage : Window
    {

        readonly WpfApp1.Classes.DataBase data = new WpfApp1.Classes.DataBase();
        public ShopPage()
        {
            InitializeComponent();
            ProductsListView();
        }


        private void ProductsListView()
        {
            DataTable dt = data.SqlSelect("Select * from Товары");
            LWProduct.ItemsSource = dt.DefaultView;
            data.CloseConnection();
        }

        private void ButtonAdd_Click(object sender, RoutedEventArgs e)
        {
            AddWindow add = new AddWindow();
            this.Hide();
            add.ShowDialog();
        }

        private void ButtonDelete_Click(object sender, RoutedEventArgs e)
        {
            DeleteWindow add = new DeleteWindow();
            add.ShowDialog();
        }

        private void ButtonPokupki_Click(object sender, RoutedEventArgs e)
        {
            Pokupki pokupki = new Pokupki();

            // Переход на новое окно
            pokupki.Show();

            // Закрытие текущего окна
            this.Close();
        }

        private void ButtonVixod_Click(object sender, RoutedEventArgs e)
        {
            MainWindow main = new MainWindow();
            main.Show();
            this.Close();
        }
    }
}
