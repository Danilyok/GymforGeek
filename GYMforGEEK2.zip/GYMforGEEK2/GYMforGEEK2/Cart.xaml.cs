﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace GYMforGEEK2
{
    /// <summary>
    /// Логика взаимодействия для Cart.xaml
    /// </summary>
    public partial class Cart : Window
    {
        public WpfApp1.Classes.DataBase data = new WpfApp1.Classes.DataBase();
        public Cart()
        {
            InitializeComponent();
        }

        private void ButtonBuy_Click(object sender, RoutedEventArgs e)
        {

            string name = Name.Text;
            string tovarr = tovar.Text;
            string kolichestvo = kol.Text;
            int costP = Convert.ToInt32(cost.Text);


            data.OpenConnection();
            try
            {
                    data.AddPokupki(name, tovarr, kolichestvo, costP);
                MessageBox.Show("Покупка завершена");
                this.Hide();
                ShopFORuser shop = new ShopFORuser();
                shop.Show();


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            data.CloseConnection();
        }

        private void ButtonAddtoCart_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
