﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace GYMforGEEK2
{
    /// <summary>
    /// Логика взаимодействия для DeleteWindow.xaml
    /// </summary>
    public partial class DeleteWindow : Window
    {
        public WpfApp1.Classes.DataBase data = new WpfApp1.Classes.DataBase();
        public DeleteWindow()
        {
            InitializeComponent();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            this.Close();
            ShopPage shop = new ShopPage();
            shop.Show();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            string name = Name.Text;
            string descr = desc.Text;
            string category = categ.Text;
            string path = photo.Text;
            int costP = Convert.ToInt32(cost.Text);

            data.OpenConnection();
            try
            {
                string query = "DELETE FROM [dbo].[Товары] WHERE [Название_товара] = '" + name + "' AND " +
                               "[Производитель_товара] = '" + descr + "' AND " +
                               "[Категория_товара] = '" + category + "' AND " +
                               "[Фото_товара] = '" + path + "' AND " +
                               "[Цена_товара] = '" + costP + "'";
                SqlCommand command = new SqlCommand(query, data.GetConnection());
                command.ExecuteNonQuery();
                MessageBox.Show("Успех!", "Сообщение об успехе", MessageBoxButton.OK);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            data.CloseConnection();
        }
    }
}
