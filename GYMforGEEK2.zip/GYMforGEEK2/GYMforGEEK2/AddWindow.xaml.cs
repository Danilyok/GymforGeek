﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace GYMforGEEK2
{
    /// <summary>
    /// Логика взаимодействия для AddWindow.xaml
    /// </summary>
    public partial class AddWindow : Window
    {
        public WpfApp1.Classes.DataBase data = new WpfApp1.Classes.DataBase();
        public AddWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

            string name = Name.Text;
            string descr = desc.Text;
            int category = Convert.ToInt32(categ.Text);
            string path = photo.Text;
            int costP = Convert.ToInt32(cost.Text);

            if (name != null && descr != null && category != null && costP!=null)
            {
                    data.AddProduct(name, descr, category, path, costP);
                MessageBox.Show("Товар успешно добавлен");
                this.Hide();
            }
            else
            {
                MessageBox.Show("Вы не ввели необходимые данные");

            }

            
        }
        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            this.Hide();
            ShopPage shop = new ShopPage();
            shop.Show();
        }
    }
}
