﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WpfApp1.Classes;

namespace GYMforGEEK2
{
    /// <summary>
    /// Логика взаимодействия для LoginWindow.xaml
    /// </summary>
    public partial class LoginWindow : Window
    {
        public LoginWindow()
        {
            InitializeComponent();
        }
        readonly DataBase dataBase = new DataBase();

        public void  Login_Click(object sender, RoutedEventArgs e)
        {

            string login = txtLogin.Text;
            string password = txtPassword.Password;
            string confirmPassword = txtConfirmPassword.Password;

            if (string.IsNullOrWhiteSpace(login) || string.IsNullOrWhiteSpace(password))
            {
                System.Windows.MessageBox.Show("Вы не ввели почту или пароль", "Ошибка ввода", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            else if (password != confirmPassword)
            {
                System.Windows.MessageBox.Show("Пароли не совпадают", "Ошибка ввода", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
            else 
            {
                if (dataBase.SqlSelect("select * from [dbo].[Пользователи] where [Логин] = '" + login + "' and [Пароль] = '" + password + "'").Rows.Count > 0)
                {
                    DataTable dt = dataBase.SqlSelect("select [FK_роли] from [dbo].[Пользователи] where [Логин] = '" + login + "'");
                    int role = Convert.ToInt32(dt.Rows[0][0]);
                    if (role == 1)
                    {
                        System.Windows.MessageBox.Show("Admin", "Успешно", MessageBoxButton.OK, MessageBoxImage.Information);
                        ShopPage shoppage = new ShopPage();
                        this.Close();
                        shoppage.Show();
                    }
                    else if (role == 2)
                    {
                        System.Windows.MessageBox.Show("User", "Успешно", MessageBoxButton.OK, MessageBoxImage.Information);
                        ShopFORuser shopforuser = new ShopFORuser();
                        this.Close();
                        shopforuser.Show();
                    }
                    else
                    {
                        System.Windows.MessageBox.Show("Ошибка", "Successfully", MessageBoxButton.OK, MessageBoxImage.Information);
                        ShopFORguest shopforguest = new ShopFORguest();
                        this.Close();
                        shopforguest.Show();
                    }
                }
                else
                {
                    System.Windows.MessageBox.Show("Данные введены неккоректно", "Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                }
            }




        }
    }
}
