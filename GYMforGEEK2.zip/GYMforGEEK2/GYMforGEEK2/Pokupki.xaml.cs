﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace GYMforGEEK2
{
    /// <summary>
    /// Логика взаимодействия для Pokupki.xaml
    /// </summary>
    public partial class Pokupki : Window
    {
        readonly WpfApp1.Classes.DataBase data = new WpfApp1.Classes.DataBase();
        public Pokupki()
        {
            InitializeComponent();
            PokupkiListView();
        }

        private void PokupkiListView()
        {
            DataTable dt = data.SqlSelect("Select * from Покупки");
            LWPokupki.ItemsSource = dt.DefaultView;
            data.CloseConnection();
        }

        private void ButtonBack_Click(object sender, RoutedEventArgs e)
        {
            ShopPage shopPage = new ShopPage();

            // Переход на новое окно
            shopPage.Show();

            // Закрытие текущего окна
            this.Close();
        }
    }
}
